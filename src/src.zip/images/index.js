const images = {
    logo: require('./webchat-logo.svg').default,
};

export default images;
